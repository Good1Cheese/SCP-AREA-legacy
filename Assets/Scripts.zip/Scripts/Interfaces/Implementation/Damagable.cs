using UnityEngine;

public class Damagable : MonoBehaviour, IDamagable
{
    public void Damage(int damageAmout)
    {
        
    }
}
