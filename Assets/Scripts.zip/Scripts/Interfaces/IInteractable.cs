using UnityEngine;



public abstract class IInteractable : MonoBehaviour
{
    public abstract void Interact();
}
