﻿using System;

public interface IDataHandler
{
    public void SaveData();

    public void LoadData();

    public string ToJson();
}

