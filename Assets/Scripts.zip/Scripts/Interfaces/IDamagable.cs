﻿interface IDamagable
{
    public void Damage(int damageAmout);
}