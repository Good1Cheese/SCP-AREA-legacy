﻿public interface IDropable
{
    public void DropItem();
}
