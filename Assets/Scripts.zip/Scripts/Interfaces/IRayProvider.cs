﻿using UnityEngine;

public interface IRayProvider
{
    Ray ProvideRay();
}