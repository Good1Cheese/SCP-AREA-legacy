﻿public interface IUseable
{
    public void UseItem();
}
