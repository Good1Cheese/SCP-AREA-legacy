using System;
using System.Collections.Generic;
using Zenject;
using UnityEngine;

[RequireComponent(typeof(CharacterBleeding))]
public class PlayerHealth : MonoBehaviour
{
    [Inject] readonly CharacterBleeding m_characterBleeding;

    public const int LastCellIndex = 0;

    public int CurrentCellIndex { get; set; }
    public int FirstCellIndex { get; set; }
    public int HealableCellIndex { get; private set; }

    public List<HealthCell> Cells { get; set; } = new List<HealthCell>();

    public Action OnPlayerDies { get; set; }
    public Action OnPlayerGetsDamage { get; set; }
    public Action OnPlayerHeals { get; set; }

    void Start()
    {
        CurrentCellIndex = Cells.Count - 1;
        HealableCellIndex = CurrentCellIndex;
        FirstCellIndex = CurrentCellIndex;
    }

    public void Damage()
    {
        GetCurrentHealthCell().MakeCellEmpty();
        CurrentCellIndex--;

        if (CurrentCellIndex < LastCellIndex)
        {
            CurrentCellIndex = 0;
            Die();
        }

        OnPlayerGetsDamage?.Invoke();
    }

    public void Heal()
    {
        if (CurrentCellIndex == FirstCellIndex
            || m_characterBleeding.IsPlayerBleeding) { return; }

        CurrentCellIndex++;
        GetCurrentHealthCell().MakeCellFull();
        OnPlayerHeals?.Invoke();
    }

    public HealthCell GetCurrentHealthCell()
    {
        return Cells[CurrentCellIndex];
    }

    public int GetCurrentHealthPercent()
    {
        return Cells.Count * 100 / Cells.Count;
    }

    public void Die()
    {
        OnPlayerDies?.Invoke();
        gameObject.SetActive(false);
    }

}
