public class EmptyDataSaving : DataHandler
{
    public override void LoadData()
    {
        print("Empty Load");
    }

    public override void SaveData()
    {
        print("Empty Save");
    }
}
