﻿using UnityEngine;

[CreateAssetMenu(fileName = "new Apple", menuName = "ScriptableObjects/Apple")]
public class Apple_SO : PickableItem_SO
{
    public override void Equip()
    {
        throw new System.NotImplementedException();
    }

    public override void Use()
    {
        
    }
}