﻿using Zenject;

public class KeyCardSlot : WearableItemSlot
{
}