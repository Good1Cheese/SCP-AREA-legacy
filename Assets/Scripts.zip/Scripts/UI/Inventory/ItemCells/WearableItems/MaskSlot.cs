﻿using Zenject;

public class MaskSlot : WearableItemSlot
{
}
